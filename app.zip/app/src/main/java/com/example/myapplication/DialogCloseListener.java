package com.example.myapplication;

import android.content.DialogInterface;

public interface DialogCloseListener {

    public void handleClose(DialogInterface di);

}
