package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.Adapter.ToDoAdapter;
import com.example.myapplication.Model.ToDoModel;
import com.example.myapplication.Utils.DataBaseHandler;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DialogCloseListener{
    private RecyclerView tasksReciclerView;
    private DataBaseHandler dbh;
    private ToDoAdapter tasksAdapter;
    private FloatingActionButton floACBut;
    private List<ToDoModel> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        dbh = new DataBaseHandler(this);
        dbh.openDatabase();

        taskList = new ArrayList<>();

        floACBut = findViewById(R.id.fab);
        floACBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddNewTask.newInstance().show(getSupportFragmentManager(), AddNewTask.TAG);
            }
        });

        ItemTouchHelper ith = new ItemTouchHelper(new RecyclerItemTouchHelper(tasksAdapter));
        ith.attachToRecyclerView(tasksReciclerView);

        tasksReciclerView = findViewById(R.id.tasksRecyclerView);
        tasksReciclerView.setLayoutManager(new LinearLayoutManager(this));
        tasksAdapter = new ToDoAdapter(dbh, this);
        tasksReciclerView.setAdapter(tasksAdapter);

        taskList = dbh.getAllTasks();
        Collections.reverse(taskList);
        tasksAdapter.setTask(taskList);
    }
    @Override
    public void handleClose(DialogInterface di){
        taskList = dbh.getAllTasks();
        Collections.reverse(taskList);
        tasksAdapter.setTask(taskList);
        tasksAdapter.notifyDataSetChanged();

    }
}